import { z } from 'zod';
import { tickets, insertTicketSchema } from './schema';

export const api = {
  tickets: {
    list: {
      method: 'GET' as const,
      path: '/api/tickets',
      responses: {
        200: z.array(z.custom<typeof tickets.$inferSelect>()),
      },
    },
    stats: {
      method: 'GET' as const,
      path: '/api/tickets/stats',
      responses: {
        200: z.object({
          total: z.number(),
          pending: z.number(),
          claimed: z.number(),
          declined: z.number(),
        }),
      },
    }
  },
  bot: {
    status: {
      method: 'GET' as const,
      path: '/api/bot/status',
      responses: {
        200: z.object({
          online: z.boolean(),
          uptime: z.number().optional(),
          lastPing: z.string().optional(),
        }),
      }
    }
  }
};
