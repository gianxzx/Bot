import { pgTable, text, serial, timestamp, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const tickets = pgTable("tickets", {
  id: serial("id").primaryKey(),
  discordMessageId: text("discord_message_id").unique(),
  webhookId: text("webhook_id"),
  content: text("content"), // The content of the webhook message
  originalEmbedData: jsonb("original_embed_data"), // Store full embed data if needed
  status: text("status").notNull().default('pending'), // pending, claimed, declined
  claimedBy: text("claimed_by"), // Discord User ID or Tag
  claimedAt: timestamp("claimed_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertTicketSchema = createInsertSchema(tickets).omit({ 
  id: true, 
  createdAt: true,
  claimedAt: true 
});

export type Ticket = typeof tickets.$inferSelect;
export type InsertTicket = z.infer<typeof insertTicketSchema>;
