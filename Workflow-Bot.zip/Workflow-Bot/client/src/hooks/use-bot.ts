import { useQuery } from "@tanstack/react-query";
import { api } from "@shared/routes";

// GET /api/bot/status
export function useBotStatus() {
  return useQuery({
    queryKey: [api.bot.status.path],
    queryFn: async () => {
      const res = await fetch(api.bot.status.path);
      if (!res.ok) throw new Error("Failed to fetch bot status");
      return api.bot.status.responses[200].parse(await res.json());
    },
    refetchInterval: 10000, // Check bot health every 10s
  });
}
