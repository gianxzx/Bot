import { useQuery } from "@tanstack/react-query";
import { api, type Ticket } from "@shared/routes";

// GET /api/tickets
export function useTickets() {
  return useQuery({
    queryKey: [api.tickets.list.path],
    queryFn: async () => {
      const res = await fetch(api.tickets.list.path);
      if (!res.ok) throw new Error("Failed to fetch tickets");
      return api.tickets.list.responses[200].parse(await res.json());
    },
    refetchInterval: 5000, // Poll every 5 seconds for real-time feel
  });
}

// GET /api/tickets/stats
export function useTicketStats() {
  return useQuery({
    queryKey: [api.tickets.stats.path],
    queryFn: async () => {
      const res = await fetch(api.tickets.stats.path);
      if (!res.ok) throw new Error("Failed to fetch ticket stats");
      return api.tickets.stats.responses[200].parse(await res.json());
    },
    refetchInterval: 5000,
  });
}
