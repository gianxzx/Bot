import { ReactNode } from "react";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";

interface MetricCardProps {
  title: string;
  value: string | number;
  icon: ReactNode;
  trend?: string;
  trendUp?: boolean;
  className?: string;
  delay?: number;
}

export function MetricCard({ title, value, icon, trend, trendUp, className, delay = 0 }: MetricCardProps) {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay, ease: "easeOut" }}
      className={cn(
        "bg-card border border-border/50 rounded-2xl p-6 relative overflow-hidden group hover:border-border transition-colors duration-300 shadow-lg shadow-black/20",
        className
      )}
    >
      <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity transform group-hover:scale-110 duration-500 text-primary">
        <div className="scale-[2.5] origin-top-right">{icon}</div>
      </div>

      <div className="flex items-center justify-between mb-4 relative z-10">
        <div className="p-3 bg-primary/10 rounded-xl text-primary ring-1 ring-primary/20">
          {icon}
        </div>
        {trend && (
          <div className={cn(
            "text-xs font-medium px-2.5 py-1 rounded-full border",
            trendUp 
              ? "bg-green-500/10 text-green-400 border-green-500/20" 
              : "bg-red-500/10 text-red-400 border-red-500/20"
          )}>
            {trend}
          </div>
        )}
      </div>

      <div className="relative z-10">
        <h3 className="text-sm font-medium text-muted-foreground tracking-wide uppercase">{title}</h3>
        <p className="text-3xl font-display font-bold text-foreground mt-1 tracking-tight">{value}</p>
      </div>
    </motion.div>
  );
}
