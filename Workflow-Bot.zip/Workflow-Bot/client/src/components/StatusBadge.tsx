import { cn } from "@/lib/utils";

type Status = "pending" | "claimed" | "declined" | "online" | "offline";

interface StatusBadgeProps {
  status: Status | string;
  className?: string;
}

export function StatusBadge({ status, className }: StatusBadgeProps) {
  const normalizedStatus = status.toLowerCase();

  const variants: Record<string, string> = {
    pending: "bg-yellow-500/10 text-yellow-500 border-yellow-500/20",
    claimed: "bg-green-500/10 text-green-500 border-green-500/20",
    declined: "bg-red-500/10 text-red-500 border-red-500/20",
    online: "bg-emerald-500/10 text-emerald-500 border-emerald-500/20 animate-pulse-slow",
    offline: "bg-gray-500/10 text-gray-500 border-gray-500/20",
  };

  const style = variants[normalizedStatus] || "bg-secondary text-secondary-foreground";

  return (
    <span className={cn(
      "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border uppercase tracking-wider",
      style,
      className
    )}>
      {normalizedStatus === "online" && (
        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mr-1.5 animate-pulse" />
      )}
      {status}
    </span>
  );
}
