import { formatDistanceToNow } from "date-fns";
import { Ticket } from "@shared/schema";
import { StatusBadge } from "./StatusBadge";
import { Loader2, ExternalLink, Clock, User, Hash } from "lucide-react";
import { motion } from "framer-motion";

interface RecentTicketsTableProps {
  tickets?: Ticket[];
  isLoading: boolean;
}

export function RecentTicketsTable({ tickets, isLoading }: RecentTicketsTableProps) {
  if (isLoading) {
    return (
      <div className="w-full h-64 flex flex-col items-center justify-center text-muted-foreground bg-card/50 rounded-2xl border border-border/50 border-dashed">
        <Loader2 className="w-8 h-8 animate-spin mb-4 text-primary" />
        <p>Loading recent activity...</p>
      </div>
    );
  }

  if (!tickets || tickets.length === 0) {
    return (
      <div className="w-full h-64 flex flex-col items-center justify-center text-muted-foreground bg-card/50 rounded-2xl border border-border/50 border-dashed">
        <div className="w-16 h-16 bg-muted/50 rounded-full flex items-center justify-center mb-4">
          <Hash className="w-8 h-8 opacity-50" />
        </div>
        <p>No tickets found yet.</p>
        <p className="text-sm opacity-50 mt-1">Wait for incoming webhooks...</p>
      </div>
    );
  }

  return (
    <div className="bg-card border border-border/50 rounded-2xl overflow-hidden shadow-lg shadow-black/5">
      <div className="p-6 border-b border-border/50 flex justify-between items-center bg-card/50 backdrop-blur-sm">
        <div>
          <h3 className="text-lg font-display font-bold text-foreground">Recent Activity</h3>
          <p className="text-sm text-muted-foreground mt-1">Live feed of incoming support requests</p>
        </div>
        <div className="flex items-center gap-2 text-xs font-mono text-muted-foreground bg-secondary/50 px-3 py-1.5 rounded-lg border border-border/50">
          <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
          LIVE UPDATES
        </div>
      </div>
      
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-border/50 bg-secondary/20">
              <th className="text-left py-4 px-6 text-xs font-semibold text-muted-foreground uppercase tracking-wider">Status</th>
              <th className="text-left py-4 px-6 text-xs font-semibold text-muted-foreground uppercase tracking-wider">Content Preview</th>
              <th className="text-left py-4 px-6 text-xs font-semibold text-muted-foreground uppercase tracking-wider">Claimed By</th>
              <th className="text-right py-4 px-6 text-xs font-semibold text-muted-foreground uppercase tracking-wider">Time</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border/30">
            {tickets.map((ticket, idx) => (
              <motion.tr 
                key={ticket.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.05 }}
                className="group hover:bg-white/[0.02] transition-colors"
              >
                <td className="py-4 px-6">
                  <StatusBadge status={ticket.status} />
                </td>
                <td className="py-4 px-6">
                  <div className="max-w-md">
                    <p className="text-sm font-medium text-foreground truncate">{ticket.content || "Embed Content"}</p>
                    <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
                      <span className="font-mono opacity-50">ID: {ticket.discordMessageId?.slice(-8) || "N/A"}</span>
                      {ticket.webhookId && (
                        <span className="bg-primary/10 text-primary px-1.5 rounded border border-primary/20">Webhook</span>
                      )}
                    </div>
                  </div>
                </td>
                <td className="py-4 px-6">
                  {ticket.claimedBy ? (
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-full bg-gradient-to-br from-indigo-500 to-purple-500 flex items-center justify-center text-[10px] text-white font-bold">
                        {ticket.claimedBy.charAt(0).toUpperCase()}
                      </div>
                      <span className="text-sm font-medium text-foreground">{ticket.claimedBy}</span>
                    </div>
                  ) : (
                    <span className="text-sm text-muted-foreground italic flex items-center gap-1">
                      <User className="w-3 h-3" /> Unclaimed
                    </span>
                  )}
                </td>
                <td className="py-4 px-6 text-right">
                  <div className="flex items-center justify-end gap-2 text-sm text-muted-foreground">
                    <Clock className="w-3 h-3" />
                    {ticket.createdAt && formatDistanceToNow(new Date(ticket.createdAt), { addSuffix: true })}
                  </div>
                </td>
              </motion.tr>
            ))}
          </tbody>
        </table>
      </div>
      
      <div className="p-4 border-t border-border/50 bg-secondary/10 flex justify-center">
        <button className="text-sm text-primary hover:text-primary/80 font-medium flex items-center gap-2 transition-colors">
          View All Tickets <ExternalLink className="w-3 h-3" />
        </button>
      </div>
    </div>
  );
}
