import { Activity, CheckCircle2, XCircle, Inbox, Server, ShieldCheck } from "lucide-react";
import { useTickets, useTicketStats } from "@/hooks/use-tickets";
import { useBotStatus } from "@/hooks/use-bot";
import { MetricCard } from "@/components/MetricCard";
import { RecentTicketsTable } from "@/components/RecentTicketsTable";
import { StatusBadge } from "@/components/StatusBadge";
import { motion } from "framer-motion";

export default function Dashboard() {
  const { data: tickets, isLoading: isLoadingTickets } = useTickets();
  const { data: stats, isLoading: isLoadingStats } = useTicketStats();
  const { data: botStatus, isLoading: isLoadingBot } = useBotStatus();

  return (
    <div className="min-h-screen bg-[#0b0e14] text-foreground p-4 md:p-8 lg:p-12 font-sans selection:bg-indigo-500/30">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header Section */}
        <header className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-6 border-b border-white/5">
          <div className="space-y-1">
            <h1 className="text-3xl md:text-4xl font-display font-bold text-white tracking-tight">
              Operations Center
            </h1>
            <p className="text-muted-foreground text-lg">
              Monitoring active webhook interceptions and bot activity.
            </p>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="bg-card border border-white/10 rounded-xl p-3 px-4 flex items-center gap-3 shadow-lg">
              <div className="space-y-0.5">
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">System Status</p>
                <div className="flex items-center gap-2">
                  {isLoadingBot ? (
                    <div className="h-5 w-24 bg-white/5 animate-pulse rounded" />
                  ) : (
                    <StatusBadge status={botStatus?.online ? "online" : "offline"} className="text-sm px-3 py-1" />
                  )}
                </div>
              </div>
              <div className="h-8 w-px bg-white/10 mx-2" />
              <div className="space-y-0.5">
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Uptime</p>
                <p className="text-sm font-mono font-medium text-foreground">
                  {isLoadingBot ? "..." : (botStatus?.uptime ? `${Math.floor(botStatus.uptime / 3600)}h ${(Math.floor(botStatus.uptime / 60) % 60)}m` : "0h 0m")}
                </p>
              </div>
            </div>
          </div>
        </header>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <MetricCard
            title="Total Tickets"
            value={isLoadingStats ? "-" : stats?.total || 0}
            icon={<Inbox className="w-6 h-6" />}
            className="border-l-4 border-l-blue-500"
            delay={0}
          />
          <MetricCard
            title="Pending Review"
            value={isLoadingStats ? "-" : stats?.pending || 0}
            icon={<Activity className="w-6 h-6" />}
            className="border-l-4 border-l-yellow-500"
            trend={stats?.pending && stats.pending > 5 ? "High Load" : "Normal"}
            trendUp={false}
            delay={0.1}
          />
          <MetricCard
            title="Claimed"
            value={isLoadingStats ? "-" : stats?.claimed || 0}
            icon={<CheckCircle2 className="w-6 h-6" />}
            className="border-l-4 border-l-green-500"
            delay={0.2}
          />
          <MetricCard
            title="Declined"
            value={isLoadingStats ? "-" : stats?.declined || 0}
            icon={<XCircle className="w-6 h-6" />}
            className="border-l-4 border-l-red-500"
            delay={0.3}
          />
        </div>

        {/* Main Content Area */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column: Recent Activity (Taking up 2/3) */}
          <div className="lg:col-span-2 space-y-6">
            <RecentTicketsTable tickets={tickets} isLoading={isLoadingTickets} />
          </div>

          {/* Right Column: Bot Health/Info (Taking up 1/3) */}
          <div className="space-y-6">
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 }}
              className="bg-card border border-border/50 rounded-2xl p-6 shadow-lg relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 p-32 bg-primary/5 rounded-full blur-3xl -mr-16 -mt-16 pointer-events-none" />
              
              <div className="flex items-center gap-3 mb-6 relative z-10">
                <div className="p-2.5 bg-secondary rounded-lg">
                  <Server className="w-5 h-5 text-primary" />
                </div>
                <h3 className="text-lg font-display font-bold">Bot Diagnostics</h3>
              </div>

              <div className="space-y-4 relative z-10">
                <div className="flex justify-between items-center p-3 bg-secondary/30 rounded-lg border border-white/5">
                  <span className="text-sm text-muted-foreground">API Latency</span>
                  <span className="text-sm font-mono text-foreground font-medium flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-green-500" />
                    24ms
                  </span>
                </div>
                <div className="flex justify-between items-center p-3 bg-secondary/30 rounded-lg border border-white/5">
                  <span className="text-sm text-muted-foreground">Gateway Ping</span>
                  <span className="text-sm font-mono text-foreground font-medium flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-green-500" />
                    42ms
                  </span>
                </div>
                <div className="flex justify-between items-center p-3 bg-secondary/30 rounded-lg border border-white/5">
                  <span className="text-sm text-muted-foreground">Memory Usage</span>
                  <span className="text-sm font-mono text-foreground font-medium">
                    124 MB
                  </span>
                </div>
              </div>

              <div className="mt-6 pt-6 border-t border-border/50">
                <div className="flex items-start gap-3">
                  <ShieldCheck className="w-5 h-5 text-emerald-500 mt-0.5" />
                  <div>
                    <h4 className="text-sm font-medium text-foreground">Operational</h4>
                    <p className="text-xs text-muted-foreground mt-1">
                      All systems functioning normally. Webhook listener is active and processing events.
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}
