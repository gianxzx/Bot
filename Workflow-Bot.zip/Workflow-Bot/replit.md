# replit.md

## Overview

This is a Discord bot operations dashboard application that monitors webhook interceptions and ticket management. The system intercepts webhook messages from Discord, stores them as tickets in a PostgreSQL database, and provides a real-time web dashboard to monitor and manage these tickets. The bot allows users to claim or decline tickets through Discord interactions.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight React router)
- **State Management**: TanStack React Query for server state with automatic polling (5-10 second intervals for real-time updates)
- **Styling**: Tailwind CSS with shadcn/ui component library (New York style variant)
- **Animations**: Framer Motion for smooth transitions
- **Build Tool**: Vite with custom path aliases (`@/` for client/src, `@shared/` for shared)

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Runtime**: Node.js with tsx for development
- **Discord Integration**: discord.js library for bot functionality
- **API Pattern**: RESTful endpoints under `/api/` prefix
- **Build**: esbuild for production bundling with selective dependency bundling

### Data Storage
- **Database**: PostgreSQL via Drizzle ORM
- **Schema Location**: `shared/schema.ts` (shared between frontend and backend)
- **Migrations**: Drizzle Kit with `db:push` command
- **Connection**: Node-postgres (pg) pool

### Project Structure
```
├── client/           # React frontend
│   └── src/
│       ├── components/   # UI components including shadcn/ui
│       ├── hooks/        # Custom React hooks
│       ├── pages/        # Route pages
│       └── lib/          # Utilities
├── server/           # Express backend
│   ├── bot.ts        # Discord bot logic
│   ├── routes.ts     # API endpoints
│   ├── storage.ts    # Database operations
│   └── db.ts         # Database connection
├── shared/           # Shared types and schemas
│   ├── schema.ts     # Drizzle schema definitions
│   └── routes.ts     # API route type definitions with Zod
└── migrations/       # Database migrations
```

### Key Design Decisions
1. **Monorepo Structure**: Client and server in single repository with shared types for type safety
2. **Schema-First Approach**: Drizzle schema with Zod validation (drizzle-zod) ensures consistent types across stack
3. **Polling for Real-Time**: Uses React Query polling rather than WebSockets for simplicity
4. **Environment-Based Serving**: Vite dev server in development, static file serving in production

## External Dependencies

### Discord Integration
- **discord.js**: Bot framework for intercepting webhook messages and handling user interactions
- **Required Environment Variables**: 
  - `DISCORD_TOKEN` - Bot authentication token
  - `INPUT_CHANNEL_ID` - Channel to monitor for webhooks

### Database
- **PostgreSQL**: Primary data store
- **Required Environment Variables**:
  - `DATABASE_URL` - PostgreSQL connection string

### UI Component Library
- **shadcn/ui**: Pre-built Radix UI components with Tailwind styling
- **Radix UI Primitives**: Accessible component foundations (dialog, dropdown, tabs, etc.)

### Development Tools
- **Replit Plugins**: Vite plugins for error overlay, cartographer, and dev banner (development only)