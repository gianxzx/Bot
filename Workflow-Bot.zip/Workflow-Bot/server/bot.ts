import { Client, GatewayIntentBits, Events, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, TextChannel, StringSelectMenuBuilder, StringSelectMenuOptionBuilder } from 'discord.js';
import { storage } from './storage';

// Export the client so we can use it in routes/other places if needed
export const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
});

let isReady = false;

export function startBot() {
  const token = process.env.DISCORD_TOKEN;
  if (!token) {
    console.warn("DISCORD_TOKEN not set. Bot will not start.");
    return;
  }

  client.login(token).catch(err => {
    console.error("Failed to login to Discord:", err);
  });
}

client.once(Events.ClientReady, c => {
  console.log(`Ready! Logged in as ${c.user.tag}`);
  isReady = true;
});

// Helper to extract user ID from mention string like <@123> or <@!123>
function extractUserId(mention: string): string | null {
  const match = mention.match(/<@!?(\d+)>/);
  return match ? match[1] : null;
}

// 1. Interception: Detect Webhook Message
client.on(Events.MessageCreate, async message => {
  // Check if message is from a webhook
  if (!message.webhookId) return;

    const inputChannelId = process.env.INPUT_CHANNEL_ID;
  if (message.channelId !== inputChannelId) return;

  console.log("Detected webhook message:", message.id);

  // Extract fields from embed if they exist
  const embeds = message.embeds;
  let robloxUser = "Unknown";
  let discordUser = "Unknown";
  let totalBill = "Unknown";
  let orderDetails = message.content || "No details";
  let specialRequests = "None";

  if (embeds.length > 0) {
    const embed = embeds[0];
    if (embed.fields) {
      const rf = embed.fields.find(f => f.name.toLowerCase().includes('roblox'));
      if (rf) robloxUser = rf.value;
      const df = embed.fields.find(f => f.name.toLowerCase().includes('discord'));
      if (df) discordUser = df.value;
      const bf = embed.fields.find(f => f.name.toLowerCase().includes('total'));
      if (bf) totalBill = bf.value;
      const of = embed.fields.find(f => f.name.toLowerCase().includes('details'));
      if (of) orderDetails = of.value;
      const sf = embed.fields.find(f => f.name.toLowerCase().includes('special'));
      if (sf) specialRequests = sf.value;
    }
  }

  // Save to DB
  const originalData = {
    content: message.content,
    embeds: embeds.map(e => e.toJSON()),
    extracted: { robloxUser, discordUser, totalBill, orderDetails, specialRequests }
  };

  try {
    // Delete original message
    await message.delete();

    // 2. Transformation: Repost original embeds with Buttons
    const row = new ActionRowBuilder<ButtonBuilder>()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('claim')
          .setLabel('Claim')
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId('decline')
          .setLabel('Decline')
          .setStyle(ButtonStyle.Danger),
      );

    const sentMessage = await message.channel.send({
      content: message.content || undefined,
      embeds: embeds.map(e => EmbedBuilder.from(e)),
      components: [row],
    });

    // Store in DB
    await storage.createTicket({
      discordMessageId: sentMessage.id,
      webhookId: message.webhookId,
      content: orderDetails, // Use extracted order details
      originalEmbedData: originalData,
      status: 'pending'
    });

  } catch (error) {
    console.error("Error processing webhook message:", error);
  }
});

// 3. Redirection: Handle Buttons and Select Menus
client.on(Events.InteractionCreate, async interaction => {
  if (interaction.isButton()) {
    const { customId, message, user } = interaction;
    
    // Find ticket in DB
    const ticket = await storage.getTicketByDiscordMessageId(message.id);
    
    if (!ticket) {
      await interaction.reply({ content: "Error: Could not find ticket record.", ephemeral: true });
      return;
    }

    if (ticket.status !== 'pending') {
      await interaction.reply({ content: `This ticket is already ${ticket.status}.`, ephemeral: true });
      return;
    }

    const queueChannelId = process.env.QUEUE_CHANNEL_ID;

    try {
      if (customId === 'claim') {
        // Update DB
        await storage.updateTicketStatus(ticket.id, 'claimed', user.tag);

        // Move to Queue Channel
        if (queueChannelId) {
          const queueChannel = await client.channels.fetch(queueChannelId) as TextChannel;
          if (queueChannel) {
            // Use extracted data from DB
            const { extracted } = (ticket.originalEmbedData as any) || {};
            const robloxUser = extracted?.robloxUser || "Unknown";
            const discordUserMention = extracted?.discordUser || user.toString();
            const totalBill = extracted?.totalBill || "Unknown";
            const orderDetails = extracted?.orderDetails || "No details";
            const specialRequests = extracted?.specialRequests || "None";

            const queueText = [
              "┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈",
              "📣 : order placed !",
              "",
              `Roblox User: **${robloxUser}**`,
              `Discord User: **${discordUserMention}**`,
              `Total Bill: **${totalBill}**`,
              `Order Details: ${orderDetails}`,
              `Special Requests: ${specialRequests}`,
              "",
              `Chef: <@${interaction.user.id}> | PST`,
              `Customer: ${discordUserMention}`,
              "Chef will ping you once the order is",
              "done! [Claim It Here](https://discord.com)",
              "",
              "**NOTED** — Just now",
              "┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈"
            ].join("\n");

            const statusMenu = new ActionRowBuilder<StringSelectMenuBuilder>()
              .addComponents(
                new StringSelectMenuBuilder()
                  .setCustomId(`status_change:${ticket.id}`)
                  .setPlaceholder('Update Order Status')
                  .addOptions(
                    new StringSelectMenuOptionBuilder()
                      .setLabel('Noted')
                      .setValue('Noted'),
                    new StringSelectMenuOptionBuilder()
                      .setLabel('Processing')
                      .setValue('Processing'),
                    new StringSelectMenuOptionBuilder()
                      .setLabel('Done')
                      .setValue('Done'),
                  ),
              );

            await queueChannel.send({ 
              content: queueText,
              components: [statusMenu]
            });
          }
        }

        // Remove from Input Channel
        await message.delete();

        await interaction.reply({ content: "Ticket claimed and moved to queue!", ephemeral: true });

      } else if (customId === 'decline') {
        // Update DB
        await storage.updateTicketStatus(ticket.id, 'declined', user.tag);

        // Delete message
        await message.delete();
        
        await interaction.reply({ content: "Ticket declined and removed.", ephemeral: true });
      }
    } catch (error) {
      console.error("Error handling interaction:", error);
      if (!interaction.replied) {
        await interaction.reply({ content: "An error occurred.", ephemeral: true });
      }
    }
  } else if (interaction.isStringSelectMenu()) {
    const { customId, values, message } = interaction;
    if (customId.startsWith('status_change:')) {
      const ticketId = parseInt(customId.split(':')[1]);
      const newStatus = values[0];

      // Check current content for "Done" status
      if (message.content.includes("**DONE**")) {
        await interaction.reply({ content: "This order is already marked as Done and cannot be changed.", ephemeral: true });
        return;
      }

      // Update text status
      const lines = message.content.split("\n");
      const statusLineIndex = lines.findIndex(l => l.includes("— Just now"));
      if (statusLineIndex !== -1) {
        lines[statusLineIndex] = `**${newStatus.toUpperCase()}** — Just now`;
      }
      
      // Ensure the divider is at the end if we edited the content
      const footerDividerIndex = lines.lastIndexOf("┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈");
      if (footerDividerIndex === -1) {
        lines.push("┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈");
      } else if (footerDividerIndex !== lines.length - 1) {
        // Move it to the very bottom
        lines.splice(footerDividerIndex, 1);
        lines.push("┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈");
      }
      
      const newContent = lines.join("\n");
      const components = newStatus === 'Done' ? [] : [interaction.message.components[0]];

      await message.edit({
        content: newContent,
        components: components as any
      });

      await interaction.reply({ content: `Status updated to ${newStatus}`, ephemeral: true });
    }
  }
});

export function getBotStatus() {
  return {
    online: isReady,
    uptime: client.uptime,
    lastPing: isReady ? new Date().toISOString() : undefined
  };
}
