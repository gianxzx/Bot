import { db } from "./db";
import { tickets, type InsertTicket, type Ticket } from "@shared/schema";
import { eq, desc, sql } from "drizzle-orm";

export interface IStorage {
  createTicket(ticket: InsertTicket): Promise<Ticket>;
  getTicket(id: number): Promise<Ticket | undefined>;
  getTicketByDiscordMessageId(messageId: string): Promise<Ticket | undefined>;
  updateTicketStatus(id: number, status: string, claimedBy?: string): Promise<Ticket>;
  getTickets(): Promise<Ticket[]>;
  getStats(): Promise<{ total: number; pending: number; claimed: number; declined: number }>;
}

export class DatabaseStorage implements IStorage {
  async createTicket(ticket: InsertTicket): Promise<Ticket> {
    const [newTicket] = await db.insert(tickets).values(ticket).returning();
    return newTicket;
  }

  async getTicket(id: number): Promise<Ticket | undefined> {
    const [ticket] = await db.select().from(tickets).where(eq(tickets.id, id));
    return ticket;
  }

  async getTicketByDiscordMessageId(messageId: string): Promise<Ticket | undefined> {
    const [ticket] = await db.select().from(tickets).where(eq(tickets.discordMessageId, messageId));
    return ticket;
  }

  async updateTicketStatus(id: number, status: string, claimedBy?: string): Promise<Ticket> {
    const updates: Partial<Ticket> = { status };
    if (claimedBy) {
      updates.claimedBy = claimedBy;
      updates.claimedAt = new Date();
    }
    
    const [updatedTicket] = await db.update(tickets)
      .set(updates)
      .where(eq(tickets.id, id))
      .returning();
    return updatedTicket;
  }

  async getTickets(): Promise<Ticket[]> {
    return await db.select().from(tickets).orderBy(desc(tickets.createdAt)).limit(50);
  }

  async getStats() {
    const allTickets = await db.select().from(tickets);
    return {
      total: allTickets.length,
      pending: allTickets.filter(t => t.status === 'pending').length,
      claimed: allTickets.filter(t => t.status === 'claimed').length,
      declined: allTickets.filter(t => t.status === 'declined').length,
    };
  }
}

export const storage = new DatabaseStorage();
