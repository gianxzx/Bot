import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { startBot, getBotStatus } from "./bot";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Start the discord bot
  startBot();

  app.get('/api/tickets', async (req, res) => {
    const tickets = await storage.getTickets();
    res.json(tickets);
  });

  app.get('/api/tickets/stats', async (req, res) => {
    const stats = await storage.getStats();
    res.json(stats);
  });

  app.get('/api/bot/status', (req, res) => {
    res.json(getBotStatus());
  });

  return httpServer;
}
